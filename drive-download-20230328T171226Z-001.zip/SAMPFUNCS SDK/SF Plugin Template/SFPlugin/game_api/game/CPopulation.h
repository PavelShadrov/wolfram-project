/*****************************************************************************
*
*  PROJECT:     Multi Theft Auto v1.0
*  LICENSE:     See LICENSE in the top level directory
*  FILE:        sdk/game/CPopulatio.h
*  PURPOSE:     Ped population interface
*
*  Multi Theft Auto is available from http://www.multitheftauto.com/
*
*****************************************************************************/

#ifndef __CGAME_POPULATION
#define __CGAME_POPULATION

#include <windows.h>
#include "CPed.h"

class CPopulation
{
public:

};

#endif
